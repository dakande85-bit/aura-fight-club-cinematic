# AURA Campaign Assets

Deploy folder: copy `public/campaign/` into the repo root.

Counts:

- `jump-rope`: 20 frames
- `sparring`: 18 frames
- `heavy-bag`: 17 frames
- `floor-ball`: 10 frames

Use `/campaign/campaign-frame-manifest.json` or `campaign-frame-arrays.js` for React frame arrays.

## jump-rope
01. `/campaign/jump-rope/jump-rope-01.webp`
02. `/campaign/jump-rope/jump-rope-02.webp`
03. `/campaign/jump-rope/jump-rope-03.webp`
04. `/campaign/jump-rope/jump-rope-04.webp`
05. `/campaign/jump-rope/jump-rope-05.webp`
06. `/campaign/jump-rope/jump-rope-06.webp`
07. `/campaign/jump-rope/jump-rope-07.webp`
08. `/campaign/jump-rope/jump-rope-08.webp`
09. `/campaign/jump-rope/jump-rope-09.webp`
10. `/campaign/jump-rope/jump-rope-10.webp`
11. `/campaign/jump-rope/jump-rope-11.webp`
12. `/campaign/jump-rope/jump-rope-12.webp`
13. `/campaign/jump-rope/jump-rope-13.webp`
14. `/campaign/jump-rope/jump-rope-14.webp`
15. `/campaign/jump-rope/jump-rope-15.webp`
16. `/campaign/jump-rope/jump-rope-16.webp`
17. `/campaign/jump-rope/jump-rope-17.webp`
18. `/campaign/jump-rope/jump-rope-18.webp`
19. `/campaign/jump-rope/jump-rope-19.webp`
20. `/campaign/jump-rope/jump-rope-20.webp`

## sparring
01. `/campaign/sparring/sparring-01.webp`
02. `/campaign/sparring/sparring-02.webp`
03. `/campaign/sparring/sparring-03.webp`
04. `/campaign/sparring/sparring-04.webp`
05. `/campaign/sparring/sparring-05.webp`
06. `/campaign/sparring/sparring-06.webp`
07. `/campaign/sparring/sparring-07.webp`
08. `/campaign/sparring/sparring-08.webp`
09. `/campaign/sparring/sparring-09.webp`
10. `/campaign/sparring/sparring-10.webp`
11. `/campaign/sparring/sparring-11.webp`
12. `/campaign/sparring/sparring-12.webp`
13. `/campaign/sparring/sparring-13.webp`
14. `/campaign/sparring/sparring-14.webp`
15. `/campaign/sparring/sparring-15.webp`
16. `/campaign/sparring/sparring-16.webp`
17. `/campaign/sparring/sparring-17.webp`
18. `/campaign/sparring/sparring-18.webp`

## heavy-bag
01. `/campaign/heavy-bag/heavy-bag-01.webp`
02. `/campaign/heavy-bag/heavy-bag-02.webp`
03. `/campaign/heavy-bag/heavy-bag-03.webp`
04. `/campaign/heavy-bag/heavy-bag-04.webp`
05. `/campaign/heavy-bag/heavy-bag-05.webp`
06. `/campaign/heavy-bag/heavy-bag-06.webp`
07. `/campaign/heavy-bag/heavy-bag-07.webp`
08. `/campaign/heavy-bag/heavy-bag-08.webp`
09. `/campaign/heavy-bag/heavy-bag-09.webp`
10. `/campaign/heavy-bag/heavy-bag-10.webp`
11. `/campaign/heavy-bag/heavy-bag-11.webp`
12. `/campaign/heavy-bag/heavy-bag-12.webp`
13. `/campaign/heavy-bag/heavy-bag-13.webp`
14. `/campaign/heavy-bag/heavy-bag-14.webp`
15. `/campaign/heavy-bag/heavy-bag-15.webp`
16. `/campaign/heavy-bag/heavy-bag-16.webp`
17. `/campaign/heavy-bag/heavy-bag-17.webp`

## floor-ball
01. `/campaign/floor-ball/floor-ball-01.webp`
02. `/campaign/floor-ball/floor-ball-02.webp`
03. `/campaign/floor-ball/floor-ball-03.webp`
04. `/campaign/floor-ball/floor-ball-04.webp`
05. `/campaign/floor-ball/floor-ball-05.webp`
06. `/campaign/floor-ball/floor-ball-06.webp`
07. `/campaign/floor-ball/floor-ball-07.webp`
08. `/campaign/floor-ball/floor-ball-08.webp`
09. `/campaign/floor-ball/floor-ball-09.webp`
10. `/campaign/floor-ball/floor-ball-10.webp`

